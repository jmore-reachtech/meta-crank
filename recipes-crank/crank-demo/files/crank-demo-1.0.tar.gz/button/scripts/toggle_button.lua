--[[
Copyright 2012, Crank Software Inc.
All Rights Reserved.
For more information email info@cranksoftware.com
** FOR DEMO PURPOSES ONLY **
]]

-- This function is called everytime the toggle button is pressed
function toggle_press( mapargs, stringargs )
	local dk_data = {}

	-- Check to see the state of the toggle check
	dk_data = gre.get_control_attrs("toggle_check", "hidden")
	if dk_data == nil then
		print("gre.control_get_attrs failed")
	end

	-- change the opposite of it's current state
	if dk_data["hidden"] == 1 then
		dk_data["hidden"] = 0
	else
		dk_data["hidden"] = 1
	end
	
	-- set the new state of the toggle_check
	gre.set_control_attrs("toggle_check", dk_data)
end

