local g_control = nil

function cb_init(mapargs)
	local data = {}
	local row = 0
	
	for n=180, 400, 5 do
		row = row + 1
		data["Temperature_layer.temperature_F.var_temp."..row..".1"] = tostring(n)
	end
	data["table_rows"] = row
	gre.set_data(data)	
	gre.send_event_target("resize_table","Temperature_layer.temperature_F")
end



-- this function is called on motion events
function drag(mapargs)
	local ev = mapargs["context_event_data"];
	local pos = {}
	
	-- if no control selected just return
	if g_control == nil then
		return
	end
	
	--set postion to touch co-od (-34 to make it center on image)
	pos["y"] = ev["y"] -  34
	
	-- set the control to the new position
	gre.set_control_attrs(g_control, pos)
end

-- on any release event on the Screen
function release(mapargs)
	g_control = nil
end


function cb_menu_options(mapargs) 
	local dk_data = {}
	--print ("I hit "  ..tostring (mapargs.context_row))

	if mapargs.context_row == 1 then
		gre.set_data({go_to_screen="Temperature_screen"})
		dk_data["menu_box_layer.submenu.selected"]="Broil"
		gre.set_data(dk_data)

	elseif mapargs.context_row == 3 then
		gre.set_data({go_to_screen="Presets_screen"})
	elseif mapargs.context_row == 2 then
		gre.set_data({go_to_screen="Temperature_screen"})
	elseif mapargs.context_row == 4 then
		gre.set_data({go_to_screen="Temperature_screen"})
	elseif mapargs.context_row == 5 then
		gre.set_data({go_to_screen="Temperature_screen"})
	end
end

local _ON = 1
local _OFF = 0

function preheat_on(mapargs) 
	if mapargs.context_row == 4 then
	    local dv = {}
	    
		dv["temperature_next_back.preheat_to_summary.grd_active"]= _ON
		dv["temperature_next_back.preheat_to_summary.grd_opaque"]= _ON
		dv["temperature_next_back.preheat_to_summary.grd_hidden"]= _OFF
		dv["Summary_layer.summary_to_preheat.grd_active"]= _ON
		dv["Summary_layer.summary_to_preheat.grd_opaque"]= _ON
		dv["Summary_layer.summary_to_preheat.grd_hidden"]= _OFF
		
		gre.set_data(dv)
	end
end
function cb_exit(mapargs) 
	--local data={}
	--data["model"]=gre.SCRIPT_ROOT.."/../../launcher./launcher_480.gapp"
	--gre.send_event_data("gre.load_app", "1s0 model", data)
	gre.quit()
end
