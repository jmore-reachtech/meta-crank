app_list = {
	{
		name = "Medical Demo",
		description = "Medical device with moving trends.",
		image = "images/thumb_medical.png",
		gapp = gre.SCRIPT_ROOT.."/../../medical/medical.gapp",
		x_res = 480,
		y_res = 272
	},
	{
		name = "Oven Demo",
		description = "White Goods Oven Demo.",
		image = "images/thumb_oven.png",
		gapp = gre.SCRIPT_ROOT.."/../../baker/FacileBake.gapp",
		x_res = 480,
		y_res = 272
	},
	{
		name = "Photo Album",
		description = "Animations that slide, fade, make data changes etc.",
		image = "images/thumb_photo.png",
		gapp = gre.SCRIPT_ROOT.."/../../photo_album/photo_album.gapp",
		x_res = 800,
		y_res = 480
	},		
}