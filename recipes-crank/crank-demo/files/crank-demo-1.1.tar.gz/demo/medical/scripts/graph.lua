-- This module contains functions that help with creating polygon arcs

--gets the final point of the circle
function get_xy_on_rect(width, height, angle)
	local g_x = width/2
	local g_y = height/2
	local radius=width/2 +5

	radian= angle * (math.pi/ 180)
	dx = g_x + radius*math.cos(radian)
	dy = g_y + radius*math.sin(radian)
	return dx, dy

	end


-- Draw an centered arc from start angle (degrees) with the specified
-- sweep angle 0 - 360 assuming a bounding box of width/height size. 
-- The angles are measured using standard cartesian planes.
--@param startdeg The starting degree point (0 degree == 3 o'clock)
--@param sweepangle The angle to run to (0 - 360)
--@param width The width of the bounding area
--@param height The height of the bounding area
--@param invert An optional parameter indicating that we want a polygon extruding
 function get_arc_points(startdeg, sweepangle, width, height, invert)
	local hwidth = math.floor(width / 2)
	local hheight = math.floor(height / 2)
	
	if(invert ~= nil) then
		sweepangle = 360 - sweepangle
	end

	--Cover the 0 sweep or > 360 sweep cases immediately
	if(sweepangle == 0) then
		return ""
	elseif(sweepangle >= 360) then
		return string.format("0:0 0:%d %d:%d %d:0", height, width, height, width) 
	end
	
	enddeg = startdeg + sweepangle
	
	local dx, dy, rad
	
	-- Start at the center point
	local pts = string.format("%d:%d ", math.floor(hwidth), math.floor(hheight))
	
	-- Determine the first point on the rectangle
	dx, dy = get_xy_on_rect(width, height, startdeg)
	pts = pts .. string.format("%d:%d ", dx, dy)

	for i = startdeg + 45, enddeg, 45 do
		local segment = math.floor(i / 45)
		if(segment == 0) then
			pts = pts .. string.format("%d:%d ", width, hheight)
		elseif(segment == 7) then
			pts = pts .. string.format("%d:%d ", width, 0)
		elseif(segment == 6) then
			pts = pts .. string.format("%d:%d ", hwidth, 0)
		elseif(segment == 5) then 
			pts = pts .. string.format("%d:%d ", 0, 0)
		elseif(segment == 4) then 
			pts = pts .. string.format("%d:%d ", 0, hheight)
		elseif(segment == 3) then 
			pts = pts .. string.format("%d:%d ", 0, height)
		elseif(segment == 2) then 
			pts = pts .. string.format("%d:%d ", hwidth, height)
		elseif(segment == 1) then 
			pts = pts .. string.format("%d:%d ", width, height)
		end 
	end
	
	-- Determine the last point on the rectangle
	dx, dy = get_xy_on_rect(width, height, enddeg)
	pts = pts .. string.format("%d:%d ", dx, dy)	

	return pts
end



local oxy_counter = 0
local upto=94
function cb_show_oxy(mapargs)
	local percent=oxy_counter/100
	local data={}
	data["blood_oxy_right_layer.chart_fill.points"]=get_arc_points(0,360*percent,90,90)
	data["blood_oxy_right_layer.blood_ox_value1.text"]=oxy_counter+1
	data["blood_oxy_right_layer.time1.text"]="NOW"
	gre.set_data(data)
	oxy_counter=oxy_counter+3

	if (oxy_counter < upto+1) then
		gre.timer_set_timeout(cb_show_oxy, 20)
	else
		oxy_counter=0

	end
end


