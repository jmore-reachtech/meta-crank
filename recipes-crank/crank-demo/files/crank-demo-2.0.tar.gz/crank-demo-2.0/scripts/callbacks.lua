function update_circ1(mapargs) 
  local data = {}
  data = gre.get_data("circle_01.blue_fill.var")

  val1 = data["circle_01.blue_fill.var"]+90
  percent1 = val1/360
  circ1_value = percent1*100
  
  gre.set_data({["circ1_value"] = tostring(string.format("%d", circ1_value))})
  
end

function update_circ2(mapargs) 
  local data = {}
  data = gre.get_data("circle2.orange_fill.var")

  val = data["circle2.orange_fill.var"]+90
  percent = val/360
  circ2_value = percent*100
  
  gre.set_data({["circ2_value"] = tostring(string.format("%d", circ2_value))})
  
end

function update_circ3(mapargs) 
  local data = {}
  data = gre.get_data("circle3.circle3_fill.var")

  val3 = data["circle3.circle3_fill.var"]+90
  percent3 = val3/360
  circ3_value = percent3*100
  
  gre.set_data({["circ_3_value"] = tostring(string.format("%d", circ3_value))})
  
end

function update_circ6(mapargs) 
  local data = {}
  data = gre.get_data("black_fade.circle_blue.var")

  val4 = data["black_fade.circle_blue.var"]+90
  percent4 = val4/360
  circ6_value = percent4*100
  
  gre.set_data({["circ_6_value"] = tostring(string.format("%d", circ6_value))})
  
end


function update_circ7(mapargs) 
  local data = {}
  data = gre.get_data("circ_7.circ7_fill.var")

  val7 = data["circ_7.circ7_fill.var"]+225
  percent7 = val7/135+2
  circ7_value = percent7*100
  
  gre.set_data({["circ_7_value"] = tostring(string.format("%d", circ7_value))})
end

function update_gauge(mapargs) 
  local data = {}
  data = gre.get_data("circle_07_layer.circ_7_fill.var")

  val_gauge = data["circle_07_layer.circ_7_fill.var"]+225
  percent_gauge = val_gauge/135+2
  gauge = percent_gauge*100
  
  gre.set_data({["gauge_value"] = tostring(string.format("%d", gauge))})
end



function update_circ_01(mapargs) 
  local data = {}
  data = gre.get_data("circle_01_layer.blue_fill.var")

  val_01 = data["circle_01_layer.blue_fill.var"]+90
  percent_01 = val_01/360
  circ_01_value = percent_01*100

  gre.set_data({["circ_01_value"] = tostring(string.format("%d", circ_01_value))})

end

function update_circ_02(mapargs) 
  local data = {}
  data = gre.get_data("circle_02_layer.orange_fill.var")

  val_02 = data["circle_02_layer.orange_fill.var"]+90
  percent_02 = val_02/360
  circ_02_value = percent_02*100

  gre.set_data({["circ_02_value"] = tostring(string.format("%d", circ_02_value))})

end

function update_circ_03(mapargs) 
  local data = {}
  data = gre.get_data("circle_03_layer.circle3_fill.var")

  val_03 = data["circle_03_layer.circle3_fill.var"]+90
  percent_03 = val_03/360
  circ_03_value = percent_03*100

  gre.set_data({["circ_03_value"] = tostring(string.format("%d", circ_03_value))})

end

function update_circ_06(mapargs) 
  local data = {}
  data = gre.get_data("circle_06_layer.circ_6.var")

  val_06 = data["circle_06_layer.circ_6.var"]+90
  percent_06 = val_06/360
  circ_06_value = percent_06*100

  gre.set_data({["circ_06_value"] = tostring(string.format("%d", circ_06_value))})

end

